Review the Unity SDK documentation at:
https://gameanalytics.com/docs/unity-sdk
